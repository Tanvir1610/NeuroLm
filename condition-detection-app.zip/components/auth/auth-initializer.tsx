"use client"

import { useEffect, useState } from "react"
import { disableEmailConfirmation } from "@/app/actions/auth-actions"

export function AuthInitializer() {
  const [initialized, setInitialized] = useState(false)

  useEffect(() => {
    const initAuth = async () => {
      if (!initialized) {
        try {
          // Disable email confirmation requirement
          await disableEmailConfirmation()
          setInitialized(true)
        } catch (error) {
          console.error("Error initializing auth:", error)
        }
      }
    }

    initAuth()
  }, [initialized])

  // This component doesn't render anything
  return null
}

