"use client"

import { useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/components/auth/auth-provider"

export function RedirectHandler() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && user) {
      const redirect = searchParams.get("redirect")
      if (redirect) {
        router.push(redirect)
      } else {
        router.push("/dashboard")
      }
    }
  }, [user, isLoading, router, searchParams])

  return null
}

