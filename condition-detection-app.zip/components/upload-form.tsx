"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, FileImage, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/components/auth/auth-provider"
import { useToast } from "@/hooks/use-toast"

export default function UploadForm() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()
  const { toast } = useToast()
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)

  // Check authentication status
  useEffect(() => {
    if (!authLoading && !user && file) {
      toast({
        title: "Authentication required",
        description: "Please login to upload and analyze scans",
        variant: "destructive",
      })
      setFile(null)
      setPreview(null)
    }
  }, [user, authLoading, file, toast])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      // Check if user is authenticated
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please login to upload and analyze scans",
          variant: "destructive",
        })
        router.push("/login?redirect=/#upload")
        return
      }

      setFile(selectedFile)

      // Create preview for image files
      if (selectedFile.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setPreview(e.target?.result as string)
        }
        reader.readAsDataURL(selectedFile)
      } else {
        setPreview(null)
      }
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    // Check if user is authenticated
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to upload and analyze scans",
        variant: "destructive",
      })
      router.push("/login?redirect=/#upload")
      return
    }

    const droppedFile = e.dataTransfer.files?.[0]
    if (droppedFile) {
      setFile(droppedFile)

      // Create preview for image files
      if (droppedFile.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setPreview(e.target?.result as string)
        }
        reader.readAsDataURL(droppedFile)
      } else {
        setPreview(null)
      }
    }
  }

  const handleRemoveFile = () => {
    setFile(null)
    setPreview(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!file) return

    // Check if user is authenticated
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to upload and analyze scans",
        variant: "destructive",
      })
      router.push("/login?redirect=/#upload")
      return
    }

    setIsUploading(true)

    // Simulate file upload and processing
    setTimeout(() => {
      setIsUploading(false)
      router.push("/results")
    }, 2000)
  }

  // If not authenticated, show login prompt
  if (!authLoading && !user) {
    return (
      <div className="text-center py-6">
        <div className="mb-4 rounded-full bg-muted p-3 mx-auto w-fit">
          <LogIn className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium mb-2">Authentication Required</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Please login or create an account to upload and analyze MRI scans.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 justify-center">
          <Button asChild>
            <a href="/login?redirect=/#upload">Login</a>
          </Button>
          <Button variant="outline" asChild>
            <a href="/signup?redirect=/#upload">Create Account</a>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div
        className={`border-2 border-dashed rounded-lg p-6 ${
          isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/20"
        } transition-colors duration-200 flex flex-col items-center justify-center text-center`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {!file ? (
          <>
            <div className="mb-4 rounded-full bg-muted p-3">
              <Upload className="h-6 w-6 text-muted-foreground" />
            </div>
            <Label htmlFor="file-upload" className="text-sm font-medium cursor-pointer text-primary hover:underline">
              Click to upload
            </Label>
            <span className="text-xs text-muted-foreground"> or drag and drop</span>
            <p className="mt-2 text-xs text-muted-foreground">Supported formats: DICOM, JPG, PNG (max 50MB)</p>
            <Input id="file-upload" type="file" accept=".dcm,image/*" onChange={handleFileChange} className="sr-only" />
          </>
        ) : (
          <div className="w-full space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="rounded-full bg-muted p-2">
                  <FileImage className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="text-sm">
                  <p className="font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              </div>
              <Button type="button" variant="ghost" size="sm" onClick={handleRemoveFile} className="h-8 w-8 p-0">
                <X className="h-4 w-4" />
                <span className="sr-only">Remove file</span>
              </Button>
            </div>

            {preview && (
              <div className="relative aspect-video w-full max-h-48 overflow-hidden rounded-lg">
                <img src={preview || "/placeholder.svg"} alt="Preview" className="object-contain w-full h-full" />
              </div>
            )}
          </div>
        )}
      </div>

      <Button type="submit" className="w-full" disabled={!file || isUploading}>
        {isUploading ? "Processing..." : "Analyze Scan"}
      </Button>
    </form>
  )
}

