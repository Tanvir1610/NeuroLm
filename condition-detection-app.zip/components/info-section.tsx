import Link from "next/link"
import { Brain, Activity, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function InfoSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Understanding Neurological Conditions
            </h2>
            <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
              Learn about the conditions our system can analyze and how our technology works.
            </p>
          </div>
        </div>

        <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <div className="mb-2 w-fit rounded-full bg-primary/10 p-2">
                <Brain className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>ADHD</CardTitle>
              <CardDescription>Attention-deficit/hyperactivity disorder</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                ADHD is a neurodevelopmental disorder characterized by inattention, hyperactivity, and impulsivity. Our
                system analyzes MRI scans for patterns that may be associated with ADHD.
              </p>
              <Link href="/about" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="mb-2 w-fit rounded-full bg-primary/10 p-2">
                <Activity className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>PTSD</CardTitle>
              <CardDescription>Post-traumatic stress disorder</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                PTSD is a mental health condition triggered by experiencing or witnessing a terrifying event. Our
                analysis looks for neurological patterns that research has associated with PTSD.
              </p>
              <Link href="/about" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="mb-2 w-fit rounded-full bg-primary/10 p-2">
                <AlertTriangle className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Down Syndrome</CardTitle>
              <CardDescription>Genetic disorder caused by chromosome 21</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Down syndrome is a genetic disorder caused by the presence of all or part of a third copy of chromosome
                21. Our system can identify patterns in brain structure associated with Down syndrome.
              </p>
              <Link href="/about" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mx-auto max-w-3xl rounded-lg bg-primary/5 p-6 text-center">
          <h3 className="mb-2 text-xl font-bold">Important Disclaimer</h3>
          <p className="text-muted-foreground">
            This application is for demonstration and educational purposes only. It is not intended for clinical
            diagnosis. Always consult with qualified healthcare professionals for medical advice and diagnosis.
          </p>
        </div>
      </div>
    </section>
  )
}

