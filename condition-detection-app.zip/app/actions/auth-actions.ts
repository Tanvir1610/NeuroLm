"use server"

import { createClient } from "@supabase/supabase-js"

export async function disableEmailConfirmation() {
  try {
    // Create a Supabase admin client with service role key
    const supabaseAdmin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    // Update auth settings to disable email confirmation
    const { error } = await supabaseAdmin.auth.admin.updateAuthConfig({
      email_confirmation_required: false,
    })

    if (error) {
      console.error("Error updating auth config:", error)
      return { success: false, message: error.message }
    }

    return { success: true, message: "Email confirmation disabled successfully" }
  } catch (error) {
    console.error("Error in disableEmailConfirmation:", error)
    return { success: false, message: "An error occurred" }
  }
}

export async function manuallyVerifyEmail(email: string) {
  try {
    // Create a Supabase admin client with service role key
    const supabaseAdmin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    // Get the user by email
    const {
      data: { users },
      error: getUserError,
    } = await supabaseAdmin.auth.admin.listUsers({
      filters: {
        email: email,
      },
    })

    if (getUserError || !users || users.length === 0) {
      console.error("Error finding user:", getUserError)
      return { success: false, message: "User not found" }
    }

    const userId = users[0].id

    // Update the user to mark email as confirmed
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, { email_confirmed: true })

    if (updateError) {
      console.error("Error updating user:", updateError)
      return { success: false, message: updateError.message }
    }

    return { success: true, message: "Email verified successfully" }
  } catch (error) {
    console.error("Error in manuallyVerifyEmail:", error)
    return { success: false, message: "An error occurred" }
  }
}

