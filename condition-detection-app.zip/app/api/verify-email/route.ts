import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ success: false, message: "Email is required" }, { status: 400 })
    }

    // Create a Supabase admin client with service role key
    const supabaseAdmin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    // Get the user by email
    const {
      data: { users },
      error: getUserError,
    } = await supabaseAdmin.auth.admin.listUsers({
      filters: {
        email: email,
      },
    })

    if (getUserError || !users || users.length === 0) {
      console.error("Error finding user:", getUserError)
      return NextResponse.json({ success: false, message: "User not found" }, { status: 404 })
    }

    const userId = users[0].id

    // Update the user to mark email as confirmed
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, { email_confirmed: true })

    if (updateError) {
      console.error("Error updating user:", updateError)
      return NextResponse.json({ success: false, message: updateError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Email verified successfully" })
  } catch (error) {
    console.error("Error in verify-email API:", error)
    return NextResponse.json({ success: false, message: "An error occurred" }, { status: 500 })
  }
}

