import { type NextRequest, NextResponse } from "next/server"
import { getServerSupabaseClient } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ exists: false, message: "Email is required" }, { status: 400 })
    }

    const supabase = getServerSupabaseClient()

    // Check if user exists in auth.users table
    const { data, error } = await supabase.from("profiles").select("id").eq("email", email).maybeSingle()

    if (error) {
      console.error("Error checking user:", error)
      return NextResponse.json({ exists: false, message: error.message }, { status: 500 })
    }

    return NextResponse.json({ exists: !!data })
  } catch (error) {
    console.error("Error in check-user API:", error)
    return NextResponse.json({ exists: false, message: "An error occurred" }, { status: 500 })
  }
}

