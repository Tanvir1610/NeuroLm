"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { Brain, ArrowLeft, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
// Import the AuthButton at the top of the file
import { AuthButton } from "@/components/auth/auth-button"

type Message = {
  role: "user" | "assistant"
  content: string
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Hello! I'm the NeuroLm Assistant. How can I help you with questions about neurological conditions or using our analysis tool?",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Fallback responses for when the API is unavailable
  const getFallbackResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase()

    if (lowerQuery.includes("adhd")) {
      return "ADHD (Attention-Deficit/Hyperactivity Disorder) is a neurodevelopmental disorder. Our application can analyze MRI patterns that may be associated with ADHD, but this is for educational purposes only. Always consult healthcare professionals for diagnosis and treatment."
    } else if (lowerQuery.includes("ptsd")) {
      return "PTSD (Post-Traumatic Stress Disorder) is a condition that can develop after experiencing traumatic events. Our application demonstrates how ML might identify patterns in brain scans, but this is not a diagnostic tool. Please consult with healthcare professionals for proper evaluation."
    } else if (lowerQuery.includes("down syndrome") || lowerQuery.includes("down's syndrome")) {
      return "Down syndrome is a genetic disorder caused by the presence of all or part of a third copy of chromosome 21. Our application shows how ML might identify patterns in brain structure, but this is for educational purposes only."
    } else if (lowerQuery.includes("how") && lowerQuery.includes("work")) {
      return "NeuroLm uses machine learning to analyze patterns in MRI scans. The technology is designed to identify potential indicators that may be associated with various neurological conditions. This is for demonstration purposes only and not for clinical diagnosis."
    } else {
      return "I'm here to provide information about neurological conditions and how our application works. Remember that NeuroLm is for educational purposes only and not for clinical diagnosis. How else can I assist you?"
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  // Add this after the initial messages state
  useEffect(() => {
    // Check if we're in fallback mode by attempting a simple API call
    const checkApiStatus = async () => {
      try {
        await generateText({
          model: openai("gpt-4o"),
          prompt: "test",
          system: "Respond with 'ok'",
        })
        // API is working, no need to show a message
      } catch (error) {
        // API has issues, add a notification message
        const errorMessage = error instanceof Error ? error.message : String(error)
        if (
          errorMessage.includes("API key") ||
          errorMessage.includes("quota") ||
          errorMessage.includes("billing") ||
          errorMessage.includes("exceeded")
        ) {
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content:
                "Note: The AI service is currently operating in offline mode. I'll provide pre-defined information about neurological conditions and our application.",
            },
          ])
        }
      }
    }

    checkApiStatus()
  }, [])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage = input.trim()
    setInput("")
    setIsLoading(true)

    // Add user message to chat
    setMessages((prev) => [...prev, { role: "user", content: userMessage }])

    try {
      // Use AI SDK to generate response
      const response = await generateText({
        model: openai("gpt-4o"),
        prompt: userMessage,
        system: `You are a helpful assistant for a neurological condition analysis application called NeuroLm.
    You can provide information about conditions like ADHD, PTSD, and Down Syndrome, and help users understand how to use the application.
    You should be informative but cautious, always emphasizing that the application is for educational purposes only and not for clinical diagnosis.
    Never provide medical advice or diagnosis. Always recommend consulting with healthcare professionals for medical concerns.
    Keep responses concise and helpful.`,
      })

      // Add assistant response to chat
      setMessages((prev) => [...prev, { role: "assistant", content: response.text }])
    } catch (error) {
      console.error("Error generating response:", error)

      // Get error message as string
      const errorMessage = error instanceof Error ? error.message : String(error)

      // Check for specific OpenAI errors
      if (
        errorMessage.includes("API key") ||
        errorMessage.includes("quota") ||
        errorMessage.includes("billing") ||
        errorMessage.includes("exceeded")
      ) {
        // Use fallback response system
        const fallbackResponse = getFallbackResponse(userMessage)
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: fallbackResponse,
          },
        ])
      } else {
        // Generic error message for other errors
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "I'm sorry, I encountered an error processing your request. Please try again later.",
          },
        ])
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </div>
          {/* Replace the navigation section in the header with this: */}
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <AuthButton />
          </nav>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-6">
        <div className="mx-auto max-w-3xl space-y-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
          </Button>

          <Card className="h-[calc(100vh-12rem)]">
            <CardHeader>
              <CardTitle>Chat with NeuroLm Assistant</CardTitle>
            </CardHeader>
            <CardContent className="overflow-y-auto h-[calc(100%-8rem)]">
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                      <Avatar className={message.role === "user" ? "bg-primary" : "bg-muted"}>
                        <AvatarFallback>{message.role === "user" ? "U" : "AI"}</AvatarFallback>
                        {message.role === "assistant" && <AvatarImage src="/placeholder.svg?height=40&width=40" />}
                      </Avatar>
                      <div
                        className={`rounded-lg p-3 ${
                          message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </CardContent>
            <CardFooter>
              <form onSubmit={handleSendMessage} className="w-full flex gap-2">
                <Input
                  placeholder="Type your message..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button type="submit" disabled={isLoading || !input.trim()}>
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </form>
            </CardFooter>
          </Card>
        </div>
      </main>

      <footer className="w-full border-t py-4">
        <div className="container text-center text-sm text-muted-foreground">
          <p>This chatbot is for informational purposes only. Not for medical advice.</p>
        </div>
      </footer>
    </div>
  )
}

