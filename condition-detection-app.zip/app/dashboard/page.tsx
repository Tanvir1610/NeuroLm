import Link from "next/link"
import { Brain, Upload, FileText, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AuthButton } from "@/components/auth/auth-button"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <AuthButton />
          </nav>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8">
        <div className="container">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
              <p className="text-muted-foreground mt-1">Manage your scans and view analysis results</p>
            </div>
            <Button className="mt-4 md:mt-0" asChild>
              <Link href="/#upload">
                <Upload className="mr-2 h-4 w-4" />
                Upload New Scan
              </Link>
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Recent Scans</CardTitle>
                <CardDescription>Your recently uploaded MRI scans</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-6 text-muted-foreground">
                  <Clock className="mx-auto h-12 w-12 opacity-50 mb-2" />
                  <p>No scans uploaded yet</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/#upload">Upload your first scan</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Analysis Results</CardTitle>
                <CardDescription>View your scan analysis results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-6 text-muted-foreground">
                  <FileText className="mx-auto h-12 w-12 opacity-50 mb-2" />
                  <p>No analysis results yet</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" disabled>
                  View Results
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Get Help</CardTitle>
                <CardDescription>Chat with our assistant</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Have questions about your results or how to use the application? Chat with our AI assistant for help.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/chat">Start Chat</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} NeuroLm. All rights reserved.
          </p>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            This is a demonstration application. Not for clinical use.
          </p>
        </div>
      </footer>
    </div>
  )
}

