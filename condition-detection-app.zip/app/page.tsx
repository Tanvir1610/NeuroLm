import { Suspense } from "react"
import Link from "next/link"
import { ArrowRight, Brain, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import UploadForm from "@/components/upload-form"
import InfoSection from "@/components/info-section"
// Import the AuthButton at the top of the file
import { AuthButton } from "@/components/auth/auth-button"
// Import the LandingHero at the top of the file
import LandingHero from "@/components/landing-hero"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </div>
          {/* Replace the navigation section in the header with this: */}
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <AuthButton />
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Replace the existing hero section with our new LandingHero component */}
        <LandingHero />

        <section id="upload" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl items-center gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Upload & Analyze</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Upload Your MRI Scan</h2>
                <p className="text-muted-foreground md:text-xl">
                  Our system uses advanced machine learning to analyze MRI scans and identify potential patterns
                  associated with various neurological conditions.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button asChild variant="outline">
                    <Link href="/chat">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Chat with Assistant
                    </Link>
                  </Button>
                  <Button asChild>
                    <Link href="/about">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="space-y-4 lg:space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Upload MRI Scan</CardTitle>
                    <CardDescription>Supported formats: DICOM, JPG, PNG (for demonstration purposes)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Suspense fallback={<div>Loading upload form...</div>}>
                      <UploadForm />
                    </Suspense>
                  </CardContent>
                  <CardFooter className="text-xs text-muted-foreground">
                    Your data is processed securely and confidentially
                  </CardFooter>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <InfoSection />
      </main>

      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} NeuroLm. All rights reserved.
          </p>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            This is a demonstration application. Not for clinical use.
          </p>
        </div>
      </footer>
    </div>
  )
}

