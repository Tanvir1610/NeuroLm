import Link from "next/link"
import { Brain } from "lucide-react"
import { AuthForm } from "@/components/auth/auth-form"
import { RedirectHandler } from "@/components/auth/redirect-handler"
import { AuthInitializer } from "@/components/auth/auth-initializer"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <AuthInitializer />
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-md">
          <RedirectHandler />
          <AuthForm type="login" />
        </div>
      </main>

      <footer className="w-full border-t py-4">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} NeuroLm. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

