"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Brain, ArrowLeft, FileText, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
// Import the AuthButton at the top of the file
import { AuthButton } from "@/components/auth/auth-button"

export default function ResultsPage() {
  const [loading, setLoading] = useState(true)

  // Simulate loading of analysis results
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  // Mock analysis results
  const mockResults = {
    fileName: "brain_scan_001.dcm",
    uploadDate: new Date().toLocaleString(),
    analysisId: "AN" + Math.floor(Math.random() * 1000000),
    conditions: {
      adhd: {
        score: 0.35,
        confidence: "Low",
        details:
          "The analysis detected some patterns that may be associated with ADHD, but with low confidence. This is not a diagnosis.",
      },
      ptsd: {
        score: 0.15,
        confidence: "Very Low",
        details: "Few indicators associated with PTSD were detected in the scan. This is not a diagnosis.",
      },
      downSyndrome: {
        score: 0.05,
        confidence: "Very Low",
        details: "Minimal indicators associated with Down Syndrome were detected. This is not a diagnosis.",
      },
    },
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </div>
          {/* Replace the navigation section in the header with this: */}
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <AuthButton />
          </nav>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-6">
        <div className="mx-auto max-w-4xl space-y-6">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
          </Button>

          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter">Analysis Results</h1>
            <p className="text-muted-foreground">Review the analysis of your uploaded MRI scan</p>
          </div>

          {loading ? (
            <Card className="p-8">
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="space-y-2 text-center">
                  <h2 className="text-xl font-semibold">Analyzing MRI Scan</h2>
                  <p className="text-sm text-muted-foreground">
                    Our system is processing your scan. This may take a moment...
                  </p>
                </div>
                <Progress value={45} className="w-full max-w-md" />
              </div>
            </Card>
          ) : (
            <div className="space-y-6">
              <Alert variant="warning">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Important Disclaimer</AlertTitle>
                <AlertDescription>
                  This analysis is for demonstration purposes only and is not a medical diagnosis. Always consult with
                  qualified healthcare professionals for medical advice.
                </AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle>Scan Information</CardTitle>
                  <CardDescription>Details about the analyzed scan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">File Name</p>
                      <p className="text-sm text-muted-foreground">{mockResults.fileName}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Upload Date</p>
                      <p className="text-sm text-muted-foreground">{mockResults.uploadDate}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Analysis ID</p>
                      <p className="text-sm text-muted-foreground">{mockResults.analysisId}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>Pattern recognition analysis for various neurological conditions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="adhd">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="adhd">ADHD</TabsTrigger>
                      <TabsTrigger value="ptsd">PTSD</TabsTrigger>
                      <TabsTrigger value="down-syndrome">Down Syndrome</TabsTrigger>
                    </TabsList>

                    <TabsContent value="adhd" className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">Pattern Recognition Score</p>
                          <p className="text-sm">{(mockResults.conditions.adhd.score * 100).toFixed(0)}%</p>
                        </div>
                        <Progress value={mockResults.conditions.adhd.score * 100} />
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Confidence Level</p>
                        <p className="text-sm">{mockResults.conditions.adhd.confidence}</p>
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Analysis Details</p>
                        <p className="text-sm text-muted-foreground">{mockResults.conditions.adhd.details}</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="ptsd" className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">Pattern Recognition Score</p>
                          <p className="text-sm">{(mockResults.conditions.ptsd.score * 100).toFixed(0)}%</p>
                        </div>
                        <Progress value={mockResults.conditions.ptsd.score * 100} />
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Confidence Level</p>
                        <p className="text-sm">{mockResults.conditions.ptsd.confidence}</p>
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Analysis Details</p>
                        <p className="text-sm text-muted-foreground">{mockResults.conditions.ptsd.details}</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="down-syndrome" className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">Pattern Recognition Score</p>
                          <p className="text-sm">{(mockResults.conditions.downSyndrome.score * 100).toFixed(0)}%</p>
                        </div>
                        <Progress value={mockResults.conditions.downSyndrome.score * 100} />
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Confidence Level</p>
                        <p className="text-sm">{mockResults.conditions.downSyndrome.confidence}</p>
                      </div>

                      <div className="space-y-1">
                        <p className="font-medium">Analysis Details</p>
                        <p className="text-sm text-muted-foreground">{mockResults.conditions.downSyndrome.details}</p>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
                <CardFooter className="flex flex-col items-start gap-2">
                  <p className="text-sm text-muted-foreground">
                    This analysis is based on pattern recognition in the provided MRI scan and is not a clinical
                    diagnosis.
                  </p>
                  <Button variant="outline" size="sm" className="gap-1">
                    <FileText className="h-4 w-4" />
                    Download Full Report
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Next Steps</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-medium">Consult with Healthcare Professionals</h3>
                    <p className="text-sm text-muted-foreground">
                      This analysis is not a diagnosis. If you have concerns about your health, please consult with
                      qualified healthcare professionals.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">Learn More</h3>
                    <p className="text-sm text-muted-foreground">
                      Visit our information pages to learn more about these conditions and how our analysis works.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button asChild variant="outline" size="sm">
                      <Link href="/about">About Our Technology</Link>
                    </Button>
                    <Button asChild variant="outline" size="sm">
                      <Link href="/chat">Chat with Assistant</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>

      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} NeuroScan Assistant. All rights reserved.
          </p>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            This is a demonstration application. Not for clinical use.
          </p>
        </div>
      </footer>
    </div>
  )
}

