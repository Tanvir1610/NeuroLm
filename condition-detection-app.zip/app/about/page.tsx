import Link from "next/link"
import { Brain, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// Import the AuthButton at the top of the file
import { AuthButton } from "@/components/auth/auth-button"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-semibold">
            <Brain className="h-6 w-6 text-primary" />
            <span>NeuroLm</span>
          </div>
          {/* Replace the navigation section in the header with this: */}
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/chat" className="text-sm font-medium">
              Chat
            </Link>
            <AuthButton />
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl space-y-8">
              <Button variant="ghost" size="sm" asChild className="mb-4">
                <Link href="/">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Home
                </Link>
              </Button>

              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About NeuroLm</h1>
                <p className="text-muted-foreground md:text-xl">
                  Understanding our approach to neurological condition analysis
                </p>
              </div>

              <div className="space-y-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Our Technology</CardTitle>
                    <CardDescription>How our analysis works</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p>
                      NeuroLm uses machine learning algorithms to analyze patterns in MRI scans. The technology is
                      designed to identify potential indicators that may be associated with various neurological
                      conditions.
                    </p>
                    <p>
                      <strong>Important Note:</strong> This application is for demonstration and educational purposes
                      only. It is not intended for clinical diagnosis. Always consult with qualified healthcare
                      professionals for medical advice and diagnosis.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Conditions We Analyze</CardTitle>
                    <CardDescription>Information about neurological conditions</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">ADHD</h3>
                      <p>
                        Attention-deficit/hyperactivity disorder (ADHD) is a neurodevelopmental disorder characterized
                        by inattention, hyperactivity, and impulsivity. While MRI scans alone cannot diagnose ADHD,
                        research has identified certain structural and functional differences in the brains of
                        individuals with ADHD.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">PTSD</h3>
                      <p>
                        Post-traumatic stress disorder (PTSD) is a mental health condition triggered by experiencing or
                        witnessing a terrifying event. Neuroimaging studies have shown differences in brain structure
                        and function in individuals with PTSD, particularly in regions involved in fear processing and
                        emotional regulation.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">Down Syndrome</h3>
                      <p>
                        Down syndrome is a genetic disorder caused by the presence of all or part of a third copy of
                        chromosome 21. Brain imaging studies have identified characteristic structural differences in
                        the brains of individuals with Down syndrome.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Data Privacy & Security</CardTitle>
                    <CardDescription>How we protect your information</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p>
                      We take data privacy and security seriously. All uploaded images are processed securely, and no
                      personal health information is stored without explicit consent. Our analysis is performed using
                      encrypted connections and follows industry best practices for medical data handling.
                    </p>
                  </CardContent>
                </Card>

                <div className="rounded-lg bg-muted p-6">
                  <h3 className="mb-4 text-lg font-medium">Disclaimer</h3>
                  <p className="text-sm text-muted-foreground">
                    This application is a technology demonstration and is not intended to provide medical advice,
                    diagnosis, or treatment. The analysis provided should not be used as a substitute for professional
                    medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified
                    health provider with any questions you may have regarding a medical condition.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} NeuroScan Assistant. All rights reserved.
          </p>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            This is a demonstration application. Not for clinical use.
          </p>
        </div>
      </footer>
    </div>
  )
}

